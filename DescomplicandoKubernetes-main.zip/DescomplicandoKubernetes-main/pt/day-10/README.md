# Descomplicando o Kubernetes
## DAY-10
&nbsp;

### O que iremos ver hoje?

Durante o dia de hoje, 



&nbsp;
### Conteúdo do Day-10

- [Por que ?](#por-que-)


&nbsp;
### Por que ?

&nbsp;

&nbsp;

### A sua lição de casa

A sua lição de casa é 

&nbsp;
## Desafio do Day-10

Não esqueça de

&nbsp;

## Final do Day-10

Durante o Day-10 você aprendeu 


&nbsp;
