# Descomplicando o Kubernetes

## DAY-9
&nbsp;

### O que iremos ver hoje?

Durante o dia de hoje, 



&nbsp;
### Conteúdo do Day-9

- [Por que ?](#por-que-)


&nbsp;
### Por que ?

&nbsp;

&nbsp;

### A sua lição de casa

A sua lição de casa é 

&nbsp;
## Desafio do Day-9

Não esqueça de

&nbsp;

## Final do Day-9

Durante o Day-9 você aprendeu 


&nbsp;
