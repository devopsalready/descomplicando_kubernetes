# Languages

* [🇧🇷 Português-brasileiro](pt/)
* [🇺🇸 English (in progress)](en/)
* [🇪🇸 Español (in progress)](es/)

![LINUXtips](images/logo-LINUXtips-2021.png)
